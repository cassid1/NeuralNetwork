#include "net_fun.h"

int main()
{
    for (double i = -10; i<=10; i++)
        cout << "i is: "<< i << ", sigmoidP(i) is: "<< sigP(i)<<endl;
}