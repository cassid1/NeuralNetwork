# OUR awesome project

Neural net with my frand butch